<?=
$title = "Error";
include("header.php");
?>

<body class="container-fluid bg-body-secondary ">

    <main class="d-flex justify-content-center align-items-center vh-100">
        <div class="text-center">
            <h1 class="display-1">404</h1>
            <p class="lead">Lo sentimos, la página que estás buscando no se pudo encontrar.</p>
            <a href="../index.php" class="btn btn-primary">Volver al inicio</a>
        </div>
    </main>
    <?php
    include("footer.php");
    ?>
</body>

</html>